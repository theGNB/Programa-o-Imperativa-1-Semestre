#include<stdio.h>
#include<stdlib.h>
#include <locale.h>

int main(void)
{
  char a;
  
  scanf("%c",&a);

  printf("%d\n",a);
  return 0;

}
